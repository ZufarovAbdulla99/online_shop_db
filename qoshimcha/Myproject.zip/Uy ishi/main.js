import express from "express"
import ejs from "ejs"
import { join } from "path"
import { readFileSync } from "fs"
// import { music_list } from "./public/js/script.js"
// import { dirname } from 'node:path';
// import { fileURLToPath } from 'node:url';
    
// const __dirname = dirname(fileURLToPath(import.meta.url));
// console.log(document)

// export const music_list = [
//     {
//         img : './public/images/stay.png',
//         name : 'Stay',
//         artist : 'The Kid LAROI, Justin Bieber',
//         music : './public/musics/stay.mp3'
//     },
//     {
//         img : './public/images/fallingdown.jpg',
//         name : 'Falling Down',
//         artist : 'Wid Cards',
//         music : './public/musics/fallingdown.mp3'
//     },
//     {
//         img : './public/images/faded.png',
//         name : 'Faded',
//         artist : 'Alan Walker',
//         music : './public/musics/Faded.mp3'
//     },
//     {
//         img : './public/images/ratherbe.jpg',
//         name : 'Rather Be',
//         artist : 'Clean Bandit',
//         music : './public/musics/Rather Be.mp3'
//     }
// ];

const app = express()

app.set("view engine", "ejs")

app.use("/public", express.static(join(process.cwd(), "public")))

app.get("/", (req, res) => { 
    const music_list = JSON.parse(readFileSync("./public/data/data.json"))
    // console.log(music_list)
    res.render("playlist", {musics: music_list})
})
app.get("/player", (req, res) => { 
    const music_list = JSON.parse(readFileSync("./public/data/data.json"))
    // console.log(music_list)
    res.render("player", {musics: music_list})
})

app.listen(3000, () => {
    console.log("Server 3000 portda ishladi...")
})