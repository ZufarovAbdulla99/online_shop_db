// import { music_list } from "../../main.js"
import fs from "fs"

const dialog = document.getElementById("dialog")
const list = document.getElementsByTagName("ul")
const delBtn = document.querySelector(".btn-del")

function showDialog(){
    dialog.showModal()
}

delBtn.addEventListener("click", () => {
    const music_list = JSON.parse(fs.readFileSync("../data/data.json", "utf-8"))
    console.log(music_list)
})