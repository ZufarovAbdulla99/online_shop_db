import { config } from "dotenv";

config()

const SERVER_PORT = process.env.SERVER_PORT;
export {SERVER_PORT}